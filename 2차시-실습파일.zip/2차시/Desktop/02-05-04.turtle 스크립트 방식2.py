import turtle

t1=turtle.Turtle()

for i in range(4) :
    t1.forward(100) 
    t1.left(90)

turtle.done()