import turtle

t1=turtle.Turtle()

for i in range(30,600,30) : 
    t1.forward(i)
    t1.left(90)

turtle.done()