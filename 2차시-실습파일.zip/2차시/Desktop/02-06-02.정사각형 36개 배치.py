import turtle

t = turtle.Turtle()
t.speed('fastest')
t.color('blue')

for i in range(36): 
    t.left(10)
    for j in range(4): 
        t.forward(150) 
        t.left(90)

turtle.done()
