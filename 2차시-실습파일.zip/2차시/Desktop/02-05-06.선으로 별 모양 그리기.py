import turtle

t1=turtle.Turtle()

for i in range(5):
    t1.forward(200)
    t1.right(144)

turtle.done()
