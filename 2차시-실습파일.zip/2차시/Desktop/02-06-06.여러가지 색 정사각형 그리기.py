import turtle

def square(t, size, color): 
    t.color(color)
    for i in range(4): 
        t.forward(size) 
        t.right(90)

t1 = turtle.Turtle()
t1.speed('fastest')
t1.penup()
t1.goto(-150,150)
t1.pendown()
t1.pensize(3)
colors = ['red', 'orange', 'yellow', 'green', 'blue', 'violet']

i=50
for color in colors: 
    square(t1, i, color) 
    i=i+50

turtle.done()