import turtle

wn = turtle.Screen() 
wn.bgcolor("lightblue") 
wn.title("Draw Triangle")

t = turtle.Turtle() 
t.color("hotpink") 
t.pensize(3)
t.goto(0, 100) 

for i in range(3):
    t.forward(200) 
    t.left(120)

t.right(180)
t.forward(200)

turtle.done()
