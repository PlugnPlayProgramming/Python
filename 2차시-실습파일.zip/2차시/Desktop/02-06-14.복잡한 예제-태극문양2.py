import turtle as t

t.bgcolor("black")
t.speed(0)
t.hideturtle()

angle=int(360/7)

for x in range(300):

    if x%7==0:
        t.color("red")
        t.forward(x*0.5)
        t.right(angle)
    
    if x%7==1:
        t.color("orange")
        t.forward(x*0.5)
        t.right(angle)

    if x%7==2:
        t.color("yellow")
        t.forward(x*0.5)
        t.right(angle)

    if x%7==3:
        t.color("green")
        t.forward(x*0.5)
        t.right(angle)

    if x%7==4:
        t.color("blue")
        t.forward(x*0.5)
        t.right(angle)

    if x%7==5:
        t.color("indigo")
        t.forward(x*0.5)
        t.right(angle)

    if x%7==6:
        t.color("violet")
        t.forward(x*0.5)
        t.right(angle)

t.mainloop()

