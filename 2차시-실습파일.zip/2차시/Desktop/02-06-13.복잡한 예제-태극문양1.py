import turtle as t

t.bgcolor("black")
t.hideturtle()
t.speed(0)

angle=int(360/3)-1

for x in range(200):

    if x%3==0:
        t.color("red")
        t.forward(x*2)
        t.right(angle)
    
    if x%3==1:
        t.color("yellow")
        t.forward(x*2)
        t.right(angle)

    if x%3==2:
        t.color("blue")
        t.forward(x*2)
        t.right(angle)


t.mainloop()

