import turtle

win=turtle.Screen()
win.bgcolor('black')

t = turtle.Turtle() 
t.speed('fastest')
t.color('red')

for i in range(50): 
    t.forward(10+i*5) 
    t.left(90) 
    t.forward(10+i*5) 
    t.left(90) 
    t.forward(10+i*5) 
    t.left(90) 
    t.forward(10+i*5) 
    t.left(80)

turtle.done()
