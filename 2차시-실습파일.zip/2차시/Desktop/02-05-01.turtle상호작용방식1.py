import turtle

turtle.position()
turtle.forward(150)

turtle.done()