import turtle

turtle.position()
turtle.forward(150)
turtle.left(90)
turtle.forward(200)

turtle.done()
