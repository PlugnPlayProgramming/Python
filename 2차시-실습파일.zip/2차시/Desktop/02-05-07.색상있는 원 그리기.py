import turtle

t = turtle.Pen() 

t.color("blue")
t.begin_fill()
t.circle(150) 
t.end_fill()

turtle.done()
