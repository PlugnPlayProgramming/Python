import turtle

win=turtle.Screen() 
win.bgcolor('black')

one = turtle.Turtle() 
one.color('yellow') 
one.pensize(2)
one.speed('fastest')

def n_one(n, size):
    for i in range(n): 
        one.circle(size)
        one.left(360.0/n)

n_one(20, 70)

turtle.done()
