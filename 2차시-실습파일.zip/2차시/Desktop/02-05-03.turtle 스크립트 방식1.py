import turtle

t1=turtle.Turtle()

t1.forward(100) 
t1.left(90) 
t1.forward(100) 
t1.left(90) 
t1.forward(100) 
t1.left(90) 
t1.forward(100) 
t1.left(90)

turtle.done()
