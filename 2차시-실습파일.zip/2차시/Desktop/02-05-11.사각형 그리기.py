import turtle

wn = turtle.Screen() 
wn.bgcolor("lightpink") 
wn.title("Draw Polygon")

a = turtle.Turtle() 
a.color("grey") 
a.pensize(5)

a.penup() 
a.goto(50, 50) 
a.pendown()

for i in range(4): 
    a.forward(200) 
    a.left(90)

turtle.done()
