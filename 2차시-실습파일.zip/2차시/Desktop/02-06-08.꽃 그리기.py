import turtle 

def flower(t, n, r, angle): 
    for i in range(n):
        for i in range(2): 
            t.circle(r,angle) 
            t.left(180-angle)
        t.left(360/n)

def move(t, length): 
    t.penup() 
    t.forward(length) 
    t.pendown()

t1 = turtle.Turtle() 
t1.speed('fastest')
t1.color("violet")

move(t1, 60)
for i in range(3):
    flower(t1, 6, 50+(50*i), 60.0)
    t1.width(2*i)

turtle.done()
