import turtle

wn = turtle.Screen()
wn.bgcolor("lightgreen")

wn.title("Hello, Tess!")

tess = turtle.Turtle() 
tess.color("hotpink") 
tess.pensize(3)

tess.forward(200) 
tess.right(120) 
tess.forward(200)

turtle.done()
