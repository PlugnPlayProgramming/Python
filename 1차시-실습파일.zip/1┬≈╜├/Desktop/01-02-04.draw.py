import turtle
wn = turtle.Screen()
wn.bgcolor("light green")
t = turtle.Turtle()
t.shape("turtle")
t.color("pink")
           
t.penup()     		# This is new
size = 20
for i in range(50):
    t.stamp() 		# Leave an impression on the canvas
    size = size + 3 # Increase the size on every iteration 
    t.forward(size) # Move tess along
    t.right(24) 	# ... and turn her
