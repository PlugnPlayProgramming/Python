outf = open('C:/test/out.txt', 'w')
outf.write("J'ai compris ta detresse \n")

outf.write("Cher amoureux \n")

outf.write("Et je cede a tes voeux \n")

outf.close()
outf = open('C:/test/out.txt', 'r')
s=outf.readlines()
print(s)
