print(1+1)
print("Hello World!")
