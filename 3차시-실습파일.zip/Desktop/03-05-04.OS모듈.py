from os import *

system('mspaint')

system('notepad')

