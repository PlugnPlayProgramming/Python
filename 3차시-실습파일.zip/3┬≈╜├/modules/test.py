import fibo as f

print(f.fib(11))
print(f.ifib(11))