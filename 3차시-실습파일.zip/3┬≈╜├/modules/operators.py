# operators.py

def add(a, b):
	print(a, '+', b, '=', a+b)

def mul(a, b):
	print(a, '*', b, '=', a*b)

def min(a, b):
	print(a, '-', b, '=', a-b)
